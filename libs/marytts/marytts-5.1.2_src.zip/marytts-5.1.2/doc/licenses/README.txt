This directory contains the licenses applicable to different products
and technologies used in MARY. See the file
"../../MARY_software_user_agreement.txt" for a detailed list of products
covered by the various licenses.
